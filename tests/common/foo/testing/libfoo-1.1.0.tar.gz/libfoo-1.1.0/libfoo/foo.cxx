// file: libfoo/foo.cxx -*- C++ -*-

#include <libfoo/foo.hxx>

#include <iostream>

using namespace std;

void
foo ()
{
  cout << "foo " << FOO_VERSION << endl;
}
