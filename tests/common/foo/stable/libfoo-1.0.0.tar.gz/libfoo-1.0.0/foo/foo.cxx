// file: foo/foo.cxx -*- C++ -*-

#include <foo/foo>

#include <iostream>

using namespace std;

void
foo ()
{
  cout << "foo " << FOO_VERSION << endl;
}
