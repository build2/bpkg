// file: libfoo/foo.hxx -*- C++ -*-

#ifndef LIBFOO_FOO_HXX
#define LIBFOO_FOO_HXX

#define LIBFOO_VERSION 10000 // 1.0.0_HXX

void
foo ();

#endif // LIBFOO_FOO_HXX
