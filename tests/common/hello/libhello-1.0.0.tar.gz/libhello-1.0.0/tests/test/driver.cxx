// file: tests/test/driver.cxx -*- C++ -*-

#include <libhello/hello.hxx>

int
main ()
{
  using hello::say;

  say ("World");
}
