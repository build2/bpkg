// file: libbar/bar.hxx -*- C++ -*-

#ifndef LIBBAR_BAR_HXX
#define LIBBAR_BAR_HXX

#define LIBBAR_VERSION 10100 // 1.1.0_HXX

void
bar ();

#endif // LIBBAR_BAR_HXX
