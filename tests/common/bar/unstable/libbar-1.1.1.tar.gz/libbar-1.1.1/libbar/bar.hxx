// file: libbar/bar.hxx -*- C++ -*-

#ifndef LIBBAR_BAR_HXX
#define LIBBAR_BAR_HXX

#define LIBBAR_VERSION 10101 // 1.1.1_HXX

void
bar ();

#endif // LIBBAR_BAR_HXX
