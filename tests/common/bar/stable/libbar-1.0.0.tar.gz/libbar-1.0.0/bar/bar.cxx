// file: bar/bar.cxx -*- C++ -*-

#include <foo/foo>

#if FOO_VERSION < 10000
#  error unsupported foo version
#endif

#include <bar/bar>

#include <iostream>

using namespace std;

void
bar ()
{
  foo ();
  cout << "bar " << BAR_VERSION << endl;
}
