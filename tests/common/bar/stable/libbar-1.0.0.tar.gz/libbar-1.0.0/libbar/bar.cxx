// file: libbar/bar.cxx -*- C++ -*-

#include <libfoo/foo.hxx>

#if FOO_VERSION < 10000
#  error unsupported foo version
#endif

#include <libbar/bar.hxx>

#include <iostream>

using namespace std;

void
bar ()
{
  foo ();
  cout << "bar " << BAR_VERSION << endl;
}
