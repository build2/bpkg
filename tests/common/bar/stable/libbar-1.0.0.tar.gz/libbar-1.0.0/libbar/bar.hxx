// file: libbar/bar.hxx -*- C++ -*-

#ifndef LIBBAR_BAR_HXX
#define LIBBAR_BAR_HXX

#define BAR_VERSION 10000 // 1.0.0

void
bar ();

#endif // LIBBAR_BAR_HXX
