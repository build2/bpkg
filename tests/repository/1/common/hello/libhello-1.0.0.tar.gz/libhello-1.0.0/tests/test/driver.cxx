// file: tests/test/driver.cxx -*- C++ -*-

#include <hello/hello>

int
main ()
{
  using hello::say;

  say ("World");
}
